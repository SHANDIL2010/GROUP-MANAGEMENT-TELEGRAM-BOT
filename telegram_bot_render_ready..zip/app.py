"""Hosting entrypoint compatibility wrapper.

Some hosting platforms automatically execute ``python app.py`` from the
project root. The actual application remains modular under ``bot/``.
"""

from bot.__main__ import main

if __name__ == "__main__":
    main()
