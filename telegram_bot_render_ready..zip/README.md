# Telegram Community Bot

A clean, modular Telegram bot built for `python-telegram-bot` 21+ with async handlers and SQLite persistence. It supports welcome messages, activity points, leaderboards, bad-word moderation, flood control, warnings, bans, admin management, and owner-only global statistics.

## Features

- **Welcome flow:** greets new group members.
- **Branded `/start`:** sends the configured welcome image with the personalized bold greeting and feature list; falls back to text if the image is unavailable.
- **Activity tracking:** records known private chats and groups, messages, and points.
- **Leaderboards:** `/leaderboard`, `/top`, and `/mystats`.
- **Auto-moderation:** configurable bad words, sliding-window flood control, warnings, and automatic ban at the warning threshold.
- **Admin controls:** `/warn`, `/unwarn`, `/ban`, `/unban`, `/admins`.
- **Owner controls:** `/addadmin`, `/removeadmin`, `/stats`.
- **Broadcast:** `/broadcast` must be sent as a reply to any message; it uses Telegram's `copyMessage` behavior so text, photos, videos, documents, captions, and other supported message types are preserved. It sends to every chat the bot has observed and stored.

## Quick start

```bash
cd telegram_bot
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
cp .env.example .env
# Edit .env and set BOT_TOKEN and OWNER_ID
python -m bot
```

Some hosting providers automatically run `python app.py`. The project includes
a root-level compatibility launcher for that hosting style. You can use either
`python app.py` or `python -m bot`; both start the same bot application.

The bot uses long polling by default. For production, run it under a process supervisor such as Docker Compose, systemd, or a managed always-on Python service. The included SQLite database is appropriate for a single bot process; move to PostgreSQL if deploying multiple replicas or expecting high write volume.

## Render deployment

Use the Render-ready project archive or connect the project repository with the
repository root selected as Render's **Root Directory**. The root directory
must contain `requirements.txt`, `app.py`, `bot/`, and `render.yaml`.

Recommended Render settings for a Background Worker:

- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `python app.py`
- **Environment variables:** `BOT_TOKEN` and numeric `OWNER_ID`

If Render reports `Could not open requirements file`, its Root Directory is
pointing to a parent folder or to an older archive. Select the folder that
directly contains `requirements.txt`, or use the Render-ready archive.

## Telegram setup

1. Create a bot with `@BotFather` and put the token in `.env`; never commit `.env`.
2. Add the bot to groups with administrator rights if it must delete messages, warn/ban members, or broadcast reliably.
3. Disable group privacy mode with `@BotFather` if the bot must inspect ordinary group messages for activity and bad words. Telegram will not deliver all group messages while privacy mode is enabled.
4. The bot can only broadcast to private users who have previously started or messaged the bot, because Telegram prevents bots from initiating conversations.
5. For username-based target commands, the user must already be known to the bot. Replying to the target message is more reliable and recommended.

## Environment

See [.env.example](.env.example). Required values are `BOT_TOKEN` and numeric `OWNER_ID`. Optional tuning includes `BAD_WORDS`, `FLOOD_WINDOW_SECONDS`, `FLOOD_MAX_MESSAGES`, `WARNING_THRESHOLD`, `POINTS_PER_MESSAGE`, `DATABASE_PATH`, `START_IMAGE_PATH`, and `LOG_LEVEL`.

## Command reference

| Command | Access | Usage |
|---|---|---|
| `/start`, `/help` | Everyone | Basic help |
| `/leaderboard`, `/top` | Everyone | Top 10 members globally |
| `/mystats` | Everyone | Your points and tracked messages |
| `/warn`, `/unwarn` | Owner/admin | Reply to a member in a group |
| `/ban`, `/unban` | Owner/admin | Reply to a member in a group |
| `/admins` | Owner/admin | List configured admins |
| `/addadmin`, `/removeadmin` | Owner | Reply to a member or use a known `@username` |
| `/admin` | Bot owner or group admin with promotion rights | In a group, reply to a joined member to promote them; the bot must be able to add administrators |
| `/broadcast` | Owner/admin | Reply to the message to copy to all known chats |
| `/stats` | Owner | Global database statistics |

## Tests and linting

```bash
pytest
ruff check bot tests
python -m compileall bot
```

## Security notes

Tokens are loaded only from environment variables using `pydantic-settings`. SQL statements are parameterized. Global bot-admin checks are performed against Telegram user IDs, not usernames. `/addadmin` and `/removeadmin` remain owner-only; `/admin` is a separate group-level promotion command that checks the caller's Telegram group role and requires the target to already be a member. Telegram API failures during broadcast are isolated per destination and reported at the end.
