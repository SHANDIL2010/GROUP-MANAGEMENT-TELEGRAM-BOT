from __future__ import annotations

import asyncio
from html import escape
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, InputFile, Update
from telegram.constants import ChatMemberStatus
from telegram.error import TelegramError
from telegram.ext import ContextTypes

from .services import bold, mention, require_admin, resolve_target

HTML = "HTML"


def _target_id(target) -> int:
    return target.id if hasattr(target, "id") else target.user_id


def _target_name(target) -> str:
    return target.full_name if hasattr(target, "full_name") else target.display_name


def _target_username(target) -> str | None:
    return getattr(target, "username", None)


def main_keyboard(owner_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🟦 🏆 Leaderboard", callback_data="leaderboard"),
                InlineKeyboardButton("🟩 📊 My stats", callback_data="mystats"),
            ],
            [
                InlineKeyboardButton("✨ Features", callback_data="features"),
                InlineKeyboardButton("🟨 Help & Commands", callback_data="help"),
            ],
            [
                InlineKeyboardButton("📢 Updates", url="https://t.me/PRO_BOTS_OFFICIAL"),
                InlineKeyboardButton("💝 Donation", url=f"tg://user?id={owner_id}"),
            ],
        ]
    )


def back_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="home")]]
    )


def welcome_text() -> str:
    return "<b>Welcome to the community bot</b>\n\nUse the buttons below to explore the bot."


def start_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    user = update.effective_user
    user_label = (
        f"@{user.username}" if user and user.username else (user.full_name if user else "there")
    )
    return (
        f"<b>HELLO !!! {escape(user_label)}</b>\n\n"
        "<b>I AM ORGANET</b>\n\n"
        "<b>What I can do:</b>\n"
        "• Welcome new group members\n"
        "• Track activity and award points\n"
        "• Show leaderboards and personal stats\n"
        "• Detect bad words and message floods\n"
        "• Manage warnings, bans, and group admins\n"
        "• Broadcast messages to known chats\n\n"
        "Use the buttons below or type <code>/help</code> to get started."
    )


def help_text() -> str:
    return (
        "<b>Bot commands</b>\n\n"
        "🏆 <code>/leaderboard</code> or <code>/top</code> — top members\n"
        "📊 <code>/mystats</code> — your points and messages\n"
        "🎖️ <code>/rank</code> — your current position\n"
        "👤 <code>/id</code> — your Telegram and chat IDs\n"
        "📜 <code>/rules</code> — view group rules\n"
        "📝 <code>/welcome</code> — view group welcome message\n\n"
        "<b>Moderation</b> (admins): <code>/warn</code>, <code>/unwarn</code>, "
        "<code>/ban</code>, <code>/unban</code>\n"
        "<b>Broadcast</b> (owner/global bot admins): reply to a message with <code>/broadcast</code>\n"
        "<b>Group administration</b>: <code>/admin</code> (reply to a joined member)\n"
        "<b>Group settings</b> (owner/group admins): <code>/setrules</code>, <code>/setwelcome</code>\n"
        "Use <code>@username</code> and <code>@userid</code> in welcome text for dynamic member details.\n"
        "<b>Auto replies</b> (owner/group admins): reply to a message/sticker with <code>/filter keyword</code>\n"
        "<code>/filters</code> — view group filters\n"
        "<code>/rfilter keyword</code> — remove one filter; <code>/rfilter all</code> — remove all\n"
        "<b>Administration</b>: <code>/admins</code>\n"
        "<b>Owner</b>: <code>/addadmin</code>, <code>/removeadmin</code>, <code>/stats</code>, <code>/botinfo</code>"
    )


def features_text() -> str:
    return (
        "<b>✨ Bot features</b>\n\n"
        "🏆 <b>Activity points</b> — earn points while participating\n"
        "📊 <b>Leaderboards</b> — see active human members\n"
        "🛡️ <b>Smart moderation</b> — flood and bad-word protection\n"
        "⚠️ <b>Warnings and bans</b> — safer, cleaner communities\n"
        "👋 <b>Welcome flow</b> — customizable group greetings\n"
        "📜 <b>Group rules</b> — admins can set rules for everyone\n"
        "📣 <b>Broadcasts</b> — owner/global-admin announcements"
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    keyboard = main_keyboard(settings.owner_id)
    image_path = Path(settings.start_image_path)
    caption = bold(start_text(update, context))
    if image_path.is_file():
        image_bytes = await asyncio.to_thread(image_path.read_bytes)
        await update.effective_message.reply_photo(
            photo=InputFile(image_bytes, filename=image_path.name),
            caption=caption,
            parse_mode=HTML,
            reply_markup=keyboard,
        )
    else:
        await update.effective_message.reply_text(caption, parse_mode=HTML, reply_markup=keyboard)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        bold(help_text()), parse_mode=HTML, reply_markup=back_keyboard()
    )


async def leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _send_leaderboard(update, context, edit=False)


async def _send_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE, edit: bool) -> None:
    chat = update.effective_chat
    group_chat_id = chat.id if chat and chat.type in {"group", "supergroup"} else None
    repo = context.application.bot_data["repo"]
    if group_chat_id is None:
        groups = await repo.get_group_leaderboard(10)
        if not groups:
            text = "<b>🏆 Most active groups</b>\n\nNo group activity recorded yet."
        else:
            lines = ["<b>🏆 Most active groups</b>", ""]
            for index, group in enumerate(groups, 1):
                title = escape(group["title"] or f"Group {group['chat_id']}")
                lines.append(
                    f"<b>{index}.</b> {title}\n"
                    f"   Messages: <b>{group['messages']}</b> · Points: <b>{group['points']}</b>"
                )
            text = "\n".join(lines)
    else:
        rows = await repo.get_leaderboard(10, group_chat_id)
        if not rows:
            text = "<b>🏆 Group leaderboard</b>\n\nNo human activity recorded yet."
        else:
            lines = ["<b>🏆 Group leaderboard</b>", ""]
            for index, row in enumerate(rows, 1):
                lines.append(
                    f"<b>{index}.</b> {mention(row.user_id, row.username, row.display_name)} "
                    f"— <b>{row.points}</b> points · {row.messages} messages"
                )
            text = "\n".join(lines)
    markup = back_keyboard()
    if edit and update.callback_query:
        await update.callback_query.edit_message_text(
            bold(text), parse_mode=HTML, reply_markup=markup
        )
    else:
        await update.effective_message.reply_text(bold(text), parse_mode=HTML, reply_markup=markup)


async def mystats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _send_mystats(update, context, edit=False)


async def _send_mystats(update: Update, context: ContextTypes.DEFAULT_TYPE, edit: bool) -> None:
    row = await context.application.bot_data["repo"].get_user(update.effective_user.id)
    if not row:
        text = "<b>📊 Your stats</b>\n\nNo stats yet — send a message to get started."
    else:
        text = (
            f"<b>📊 Your stats</b>\n\n"
            f"Points: <b>{row.points}</b>\nTracked messages: <b>{row.messages}</b>"
        )
    if edit and update.callback_query:
        await update.callback_query.edit_message_text(
            bold(text), parse_mode=HTML, reply_markup=back_keyboard()
        )
    else:
        await update.effective_message.reply_text(
            bold(text), parse_mode=HTML, reply_markup=back_keyboard()
        )


async def button_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    await query.answer()
    if query.data == "leaderboard":
        await _send_leaderboard(update, context, edit=True)
    elif query.data == "mystats":
        await _send_mystats(update, context, edit=True)
    elif query.data == "features":
        await query.edit_message_text(
            bold(features_text()), parse_mode=HTML, reply_markup=back_keyboard()
        )
    elif query.data == "help":
        await query.edit_message_text(
            bold(help_text()), parse_mode=HTML, reply_markup=back_keyboard()
        )
    elif query.data == "home":
        owner_id = context.application.bot_data["settings"].owner_id
        await query.edit_message_text(
            bold(welcome_text()), parse_mode=HTML, reply_markup=main_keyboard(owner_id)
        )


async def user_id_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    chat = update.effective_chat
    username = f"@{escape(user.username)}" if user and user.username else "Not set"
    text = (
        "<b>👤 Your Telegram info</b>\n\n"
        f"User: <b>{escape(user.full_name if user else 'Unknown')}</b>\n"
        f"Username: <b>{username}</b>\n"
        f"User ID: <code>{user.id if user else 'unknown'}</code>\n"
        f"Chat ID: <code>{chat.id if chat else 'unknown'}</code>"
    )
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def rules(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await show_rules(update, context)


async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _show_group_setting(
        update, context, "rules_text", "📜 Group rules", "No group rules have been set yet."
    )


async def show_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _show_group_setting(
        update,
        context,
        "welcome_text",
        "👋 Group welcome message",
        "Welcome @username! Please read the group rules and enjoy your stay.",
    )


async def _show_group_setting(
    update: Update, context: ContextTypes.DEFAULT_TYPE, field: str, title: str, default: str
) -> None:
    chat = update.effective_chat
    if not chat or chat.type not in {"group", "supergroup"}:
        await update.effective_message.reply_text(
            bold("This command can only be used inside a group."), parse_mode=HTML
        )
        return
    value = await context.application.bot_data["repo"].get_group_setting(chat.id, field)
    text = f"<b>{title}</b>\n\n{escape(value or default)}"
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def rank(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    chat = update.effective_chat
    group_chat_id = chat.id if chat and chat.type in {"group", "supergroup"} else None
    row = await context.application.bot_data["repo"].get_user(user.id)
    position = await context.application.bot_data["repo"].get_user_rank(user.id, group_chat_id)
    if not row or position is None:
        await update.effective_message.reply_text(
            bold("🎖️ You do not have a rank yet. Send a message to start earning points."),
            parse_mode=HTML,
        )
        return
    text = (
        "<b>🎖️ Your rank</b>\n\n"
        f"Position: <b>#{position}</b>\n"
        f"Points: <b>{row.points}</b>\n"
        f"Messages: <b>{row.messages}</b>"
    )
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def rules_command_alias(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await show_rules(update, context)


async def bot_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    if update.effective_user.id != settings.owner_id:
        await update.effective_message.reply_text(
            bold("Only the bot owner can view bot information."), parse_mode=HTML
        )
        return
    stats = await context.application.bot_data["repo"].global_stats()
    me = await context.bot.get_me()
    text = (
        "<b>🤖 Bot information</b>\n\n"
        f"Name: <b>{escape(me.first_name)}</b>\n"
        f"Username: <b>@{escape(me.username or 'unknown')}</b>\n"
        f"Known users: <b>{stats['users']}</b>\n"
        f"Known chats: <b>{stats['chats']}</b>\n"
        f"Tracked messages: <b>{stats['messages']}</b>\n"
        f"Total points: <b>{stats['points']}</b>"
    )
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def admins(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    if chat and chat.type in {"group", "supergroup"}:
        try:
            group_admins = await context.bot.get_chat_administrators(chat.id)
        except TelegramError:
            await update.effective_message.reply_text(
                bold("I could not read this group's administrator list. Check my permissions."),
                parse_mode=HTML,
            )
            return
        lines = [f"<b>👥 {escape(chat.title or 'Group')} administrators</b>", ""]
        for member in group_admins:
            role = "Owner" if member.status == ChatMemberStatus.OWNER else "Admin"
            user = member.user
            username = f"@{escape(user.username)}" if user.username else f"ID {user.id}"
            lines.append(f"• <b>{escape(user.full_name)}</b> — {role} ({username})")
        await update.effective_message.reply_text(bold("\n".join(lines)), parse_mode=HTML)
        return

    if not await require_admin(update, context):
        return
    repo = context.application.bot_data["repo"]
    settings = context.application.bot_data["settings"]
    rows = await repo.list_admins()
    lines = [
        f"<b>🤖 Bot owner</b>: <code>{settings.owner_id}</code>",
        "",
        "<b>Global bot admins</b>",
    ]
    if rows:
        lines.extend(
            f"• {escape(r['display_name'])} "
            f"({escape('@' + r['username']) if r['username'] else 'ID ' + str(r['user_id'])})"
            for r in rows
        )
    else:
        lines.append("No additional global bot admins configured.")
    await update.effective_message.reply_text(bold("\n".join(lines)), parse_mode=HTML)


async def add_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    if update.effective_user.id != settings.owner_id:
        await update.effective_message.reply_text(
            bold("Only the owner can manage admins."), parse_mode=HTML
        )
        return
    target = await resolve_target(update, context)
    if not target:
        await update.effective_message.reply_text(
            bold("Reply to a user or provide a known @username."), parse_mode=HTML
        )
        return
    await context.application.bot_data["repo"].add_admin(
        _target_id(target), _target_username(target), _target_name(target)
    )
    await update.effective_message.reply_text(
        bold(
            f"Added {mention(_target_id(target), _target_username(target), _target_name(target))} as an admin."
        ),
        parse_mode=HTML,
    )


async def remove_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    if update.effective_user.id != settings.owner_id:
        await update.effective_message.reply_text(
            bold("Only the owner can manage admins."), parse_mode=HTML
        )
        return
    target = await resolve_target(update, context)
    if not target:
        await update.effective_message.reply_text(
            bold("Usage: reply to an admin with /removeadmin or use /removeadmin @username."),
            parse_mode=HTML,
        )
        return
    target_id = _target_id(target)
    if target_id == settings.owner_id:
        await update.effective_message.reply_text(
            bold("The bot owner cannot be removed as an admin."), parse_mode=HTML
        )
        return
    removed = await context.application.bot_data["repo"].remove_admin(target_id)
    if not removed:
        await update.effective_message.reply_text(
            bold("That user is not a configured global bot admin."), parse_mode=HTML
        )
        return
    await update.effective_message.reply_text(
        bold(
            f"Removed {mention(target_id, _target_username(target), _target_name(target))} "
            "from global bot admins."
        ),
        parse_mode=HTML,
    )


async def promote_group_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    actor = update.effective_user
    settings = context.application.bot_data["settings"]
    if not message or not chat or not actor or chat.type not in {"group", "supergroup"}:
        await message.reply_text(
            bold("Use /admin inside a group by replying to a joined member."), parse_mode=HTML
        )
        return
    authorized = actor.id == settings.owner_id
    try:
        actor_member = await context.bot.get_chat_member(chat.id, actor.id)
        authorized = authorized or (
            actor_member.status == ChatMemberStatus.OWNER
            or (
                actor_member.status == ChatMemberStatus.ADMINISTRATOR
                and bool(actor_member.can_promote_members)
            )
        )
    except TelegramError:
        authorized = False
    if not authorized:
        await message.reply_text(
            bold(
                "Only the bot owner or a group administrator with permission to add admins can use /admin."
            ),
            parse_mode=HTML,
        )
        return
    target = await resolve_target(update, context)
    if not target:
        await message.reply_text(bold("Reply to the member you want to promote."), parse_mode=HTML)
        return
    try:
        target_member = await context.bot.get_chat_member(chat.id, _target_id(target))
        if target_member.status in {ChatMemberStatus.LEFT, ChatMemberStatus.BANNED}:
            await message.reply_text(
                bold("That user must join the group before becoming an admin."), parse_mode=HTML
            )
            return
        await context.bot.promote_chat_member(
            chat.id,
            _target_id(target),
            can_delete_messages=True,
            can_restrict_members=True,
            can_invite_users=True,
            can_pin_messages=True,
            can_manage_video_chats=True,
            can_manage_topics=True,
            can_promote_members=False,
        )
    except TelegramError:
        await message.reply_text(
            bold(
                "I could not promote that member. Check my admin permissions and make sure the target joined the group."
            ),
            parse_mode=HTML,
        )
        return
    await message.reply_text(
        bold(
            f"Promoted {mention(_target_id(target), _target_username(target), _target_name(target))} to group admin."
        ),
        parse_mode=HTML,
    )


async def warn(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, context):
        return
    target = await resolve_target(update, context)
    if not target or update.effective_chat.type == "private":
        await update.effective_message.reply_text(
            bold("Use this in a group by replying to a member."), parse_mode=HTML
        )
        return
    repo = context.application.bot_data["repo"]
    count = await repo.add_warning(update.effective_chat.id, _target_id(target))
    threshold = context.application.bot_data["settings"].warning_threshold
    if count >= threshold:
        try:
            await context.bot.ban_chat_member(update.effective_chat.id, _target_id(target))
            await update.effective_message.reply_text(
                bold(f"{escape(_target_name(target))} reached {count} warnings and was banned."),
                parse_mode=HTML,
            )
        except TelegramError:
            await update.effective_message.reply_text(
                bold(f"{escape(_target_name(target))} has {count} warnings; I could not ban them."),
                parse_mode=HTML,
            )
    else:
        await update.effective_message.reply_text(
            bold(f"{escape(_target_name(target))} warned ({count}/{threshold})."), parse_mode=HTML
        )


async def unwarn(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, context):
        return
    target = await resolve_target(update, context)
    if not target or update.effective_chat.type == "private":
        await update.effective_message.reply_text(
            bold("Use this in a group by replying to a member."), parse_mode=HTML
        )
        return
    count = await context.application.bot_data["repo"].remove_warning(
        update.effective_chat.id, _target_id(target)
    )
    await update.effective_message.reply_text(
        bold(f"{escape(_target_name(target))} now has {count} warning(s)."), parse_mode=HTML
    )


async def ban(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, context):
        return
    target = await resolve_target(update, context)
    if not target or update.effective_chat.type == "private":
        await update.effective_message.reply_text(
            bold("Use this in a group by replying to a member."), parse_mode=HTML
        )
        return
    await context.bot.ban_chat_member(update.effective_chat.id, _target_id(target))
    await update.effective_message.reply_text(
        bold(f"Banned {escape(_target_name(target))}."), parse_mode=HTML
    )


async def unban(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, context):
        return
    target = await resolve_target(update, context)
    if not target or update.effective_chat.type == "private":
        await update.effective_message.reply_text(
            bold("Use this in a group by replying to a member."), parse_mode=HTML
        )
        return
    await context.bot.unban_chat_member(
        update.effective_chat.id, _target_id(target), only_if_banned=True
    )
    await update.effective_message.reply_text(
        bold(f"Unbanned {escape(_target_name(target))}."), parse_mode=HTML
    )


async def global_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    if update.effective_user.id != settings.owner_id:
        await update.effective_message.reply_text(
            bold("Only the owner can view global stats."), parse_mode=HTML
        )
        return
    stats = await context.application.bot_data["repo"].global_stats()
    text = "<b>Global statistics</b>\n\n" + "\n".join(
        f"{escape(key.title())}: <b>{value}</b>" for key, value in stats.items()
    )
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def set_group_filter(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_group_admin(update, context):
        return
    trigger = " ".join(context.args).strip()
    source = update.effective_message.reply_to_message
    if not trigger or not source:
        await update.effective_message.reply_text(
            bold("Usage: reply to any message or sticker and send /filter keyword"),
            parse_mode=HTML,
        )
        return
    if len(trigger) > 64:
        await update.effective_message.reply_text(
            bold("Keep the keyword under 64 characters."),
            parse_mode=HTML,
        )
        return
    response = source.text or source.caption or "Saved message"
    await context.application.bot_data["repo"].set_filter(
        update.effective_chat.id,
        trigger,
        response,
        source_chat_id=source.chat_id,
        source_message_id=source.message_id,
    )
    await update.effective_message.reply_text(
        bold(f"✅ Filter saved for: {escape(trigger)}"), parse_mode=HTML
    )


async def remove_group_filter(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_group_admin(update, context):
        return
    trigger = " ".join(context.args).strip()
    if not trigger:
        await update.effective_message.reply_text(
            bold("Usage: /rfilter keyword, or /rfilter all to remove every group filter."),
            parse_mode=HTML,
        )
        return
    repo = context.application.bot_data["repo"]
    if trigger.casefold() == "all":
        removed = await repo.clear_filters(update.effective_chat.id)
        await update.effective_message.reply_text(
            bold(f"✅ Removed {removed} group filter(s)."), parse_mode=HTML
        )
        return
    removed = await repo.remove_filter(update.effective_chat.id, trigger)
    if removed:
        text = f"✅ Removed filter: {escape(trigger)}"
    else:
        text = f"No filter found for: {escape(trigger)}"
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def list_group_filters(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    if not chat or chat.type not in {"group", "supergroup"}:
        await update.effective_message.reply_text(
            bold("This command can only be used inside a group."), parse_mode=HTML
        )
        return
    rows = await context.application.bot_data["repo"].list_filters(chat.id)
    if not rows:
        text = "<b>🔔 Group filters</b>\n\nNo filters have been configured yet."
    else:
        lines = ["<b>🔔 Group filters</b>", ""]
        lines.extend(
            f"• <code>{escape(trigger)}</code> → {escape(response)}" for trigger, response in rows
        )
        text = "\n".join(lines)
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)


async def _require_group_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    chat = update.effective_chat
    actor = update.effective_user
    settings = context.application.bot_data["settings"]
    if not chat or chat.type not in {"group", "supergroup"}:
        await update.effective_message.reply_text(
            bold("This command can only be used inside a group."), parse_mode=HTML
        )
        return False
    if actor and actor.id == settings.owner_id:
        return True
    try:
        member = await context.bot.get_chat_member(chat.id, actor.id)
        if member.status in {ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER}:
            return True
    except TelegramError:
        pass
    await update.effective_message.reply_text(
        bold("Only the bot owner or a Telegram group admin can change this setting."),
        parse_mode=HTML,
    )
    return False


def _setting_value(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    message = update.effective_message
    if message and message.reply_to_message:
        source = message.reply_to_message
        value = source.text or source.caption
        if value:
            return value.strip()
    return " ".join(context.args).strip()


async def _set_group_setting(
    update: Update, context: ContextTypes.DEFAULT_TYPE, field: str, label: str
) -> None:
    if not await _require_group_admin(update, context):
        return
    value = _setting_value(update, context)
    if not value:
        command = "setrules" if field == "rules_text" else "setwelcome"
        await update.effective_message.reply_text(
            bold(f"Usage: /{command} your message here, or reply to a message."), parse_mode=HTML
        )
        return
    if len(value) > 3500:
        await update.effective_message.reply_text(
            bold(f"{label.title()} is too long. Please keep it under 3,500 characters."),
            parse_mode=HTML,
        )
        return
    await context.application.bot_data["repo"].set_group_setting(
        update.effective_chat.id, field, value
    )
    await update.effective_message.reply_text(
        bold(f"✅ Group {label.lower()} updated successfully."), parse_mode=HTML
    )


async def set_rules(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _set_group_setting(update, context, "rules_text", "rules")


async def set_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_group_admin(update, context):
        return
    source = update.effective_message.reply_to_message
    media_type = None
    media_file_id = None
    if source:
        if source.photo:
            media_type, media_file_id = "photo", source.photo[-1].file_id
        elif source.animation:
            media_type, media_file_id = "animation", source.animation.file_id
        elif source.video:
            media_type, media_file_id = "video", source.video.file_id
    if media_type:
        caption = " ".join(context.args).strip() or source.caption or "Welcome @username!"
        if len(caption) > 1024:
            await update.effective_message.reply_text(
                bold("The media caption must be under 1,024 characters."), parse_mode=HTML
            )
            return
        await context.application.bot_data["repo"].set_welcome_content(
            update.effective_chat.id,
            caption,
            source_chat_id=source.chat_id,
            source_message_id=source.message_id,
            media_type=media_type,
            media_file_id=media_file_id,
            caption=caption,
        )
        await update.effective_message.reply_text(
            bold("✅ Group welcome media updated. @username and @userid will be personalized."),
            parse_mode=HTML,
        )
        return
    await _set_group_setting(update, context, "welcome_text", "welcome message")


async def _show_group_setting(
    update: Update, context: ContextTypes.DEFAULT_TYPE, field: str, title: str, default: str
) -> None:
    chat = update.effective_chat
    if not chat or chat.type not in {"group", "supergroup"}:
        await update.effective_message.reply_text(
            bold("This command can only be used inside a group."), parse_mode=HTML
        )
        return
    value = await context.application.bot_data["repo"].get_group_setting(chat.id, field)
    text = f"<b>{title}</b>\n\n{escape(value or default)}"
    await update.effective_message.reply_text(bold(text), parse_mode=HTML)
