from __future__ import annotations

import re
import time
from collections import defaultdict, deque
from html import escape
from typing import TYPE_CHECKING

from telegram import Update
from telegram.ext import ContextTypes

if TYPE_CHECKING:
    from .config import Settings
    from .repository import Repository


class FloodGuard:
    def __init__(self, window_seconds: int, max_messages: int) -> None:
        self.window = window_seconds
        self.maximum = max_messages
        self._events: defaultdict[tuple[int, int], deque[float]] = defaultdict(deque)

    def hit(self, chat_id: int, user_id: int) -> bool:
        now = time.monotonic()
        events = self._events[(chat_id, user_id)]
        while events and now - events[0] > self.window:
            events.popleft()
        events.append(now)
        return len(events) > self.maximum


def contains_bad_word(text: str | None, bad_words: list[str]) -> bool:
    if not text:
        return False
    normalized = text.casefold()
    return any(re.search(rf"(?<!\w){re.escape(word)}(?!\w)", normalized) for word in bad_words)


def mention(user_id: int, username: str | None, display_name: str) -> str:
    return (
        f"@{escape(username)}"
        if username
        else f'<a href="tg://user?id={user_id}">{escape(display_name)}</a>'
    )


def bold(text: str) -> str:
    return f"<b>{text}</b>"


async def require_bot_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Allow only the configured owner or globally added bot admins."""
    message = update.effective_message
    user = update.effective_user
    repo: Repository = context.application.bot_data["repo"]
    settings: Settings = context.application.bot_data["settings"]
    if not user or not await repo.is_admin(user.id, settings.owner_id):
        if message:
            await message.reply_text(
                bold("This command is restricted to the owner and configured admins."),
                parse_mode="HTML",
            )
        return False
    return True


async def require_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Backward-compatible alias for global bot-admin authorization."""
    return await require_bot_admin(update, context)


async def resolve_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Resolve a replied-to user or a known @username in the local database."""
    message = update.effective_message
    repo: Repository = context.application.bot_data["repo"]
    if message and message.reply_to_message and message.reply_to_message.from_user:
        return message.reply_to_message.from_user
    if context.args:
        handle = context.args[0].lstrip("@").casefold()
        return await repo.find_user_by_username(handle)
    return None
