"""Persistence layer. All SQL is parameterized and connections are short-lived."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import aiosqlite


@dataclass(slots=True)
class UserRecord:
    user_id: int
    username: str | None
    display_name: str
    points: int
    messages: int


class Repository:
    def __init__(self, path: str) -> None:
        self.path = path
        self._filter_cache: dict[int, list[tuple[str, str]]] = {}
        self._filter_match_cache: dict[int, list[tuple[str, str, int | None, int | None]]] = {}

    async def initialize(self) -> None:
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.path) as db:
            await db.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS chats (
                    chat_id INTEGER PRIMARY KEY,
                    chat_type TEXT NOT NULL,
                    title TEXT,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    display_name TEXT NOT NULL,
                    points INTEGER NOT NULL DEFAULT 0,
                    messages INTEGER NOT NULL DEFAULT 0,
                    is_bot INTEGER NOT NULL DEFAULT 0,
                    last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS chat_members (
                    chat_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    first_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (chat_id, user_id),
                    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS chat_activity (
                    chat_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    points INTEGER NOT NULL DEFAULT 0,
                    messages INTEGER NOT NULL DEFAULT 0,
                    last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (chat_id, user_id),
                    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS admins (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    display_name TEXT NOT NULL,
                    added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS warnings (
                    chat_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    count INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (chat_id, user_id)
                );
                CREATE TABLE IF NOT EXISTS group_settings (
                    chat_id INTEGER PRIMARY KEY,
                    rules_text TEXT,
                    welcome_text TEXT,
                    welcome_source_chat_id INTEGER,
                    welcome_source_message_id INTEGER,
                    welcome_media_type TEXT,
                    welcome_media_file_id TEXT,
                    welcome_caption TEXT,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS group_filters (
                    chat_id INTEGER NOT NULL,
                    trigger TEXT NOT NULL,
                    response TEXT NOT NULL,
                    source_chat_id INTEGER,
                    source_message_id INTEGER,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (chat_id, trigger)
                );
                CREATE INDEX IF NOT EXISTS idx_users_points ON users(points DESC);
                CREATE INDEX IF NOT EXISTS idx_members_chat ON chat_members(chat_id);
                CREATE INDEX IF NOT EXISTS idx_activity_chat ON chat_activity(chat_id, points DESC, messages DESC);
                """
            )
            columns = await db.execute_fetchall("PRAGMA table_info(users)")
            if not any(column[1] == "is_bot" for column in columns):
                await db.execute("ALTER TABLE users ADD COLUMN is_bot INTEGER NOT NULL DEFAULT 0")
            filter_columns = await db.execute_fetchall("PRAGMA table_info(group_filters)")
            existing_filter_columns = {column[1] for column in filter_columns}
            for column in ("source_chat_id", "source_message_id"):
                if column not in existing_filter_columns:
                    await db.execute(f"ALTER TABLE group_filters ADD COLUMN {column} INTEGER")
            settings_columns = await db.execute_fetchall("PRAGMA table_info(group_settings)")
            existing_settings_columns = {column[1] for column in settings_columns}
            for column, sql_type in (
                ("welcome_source_chat_id", "INTEGER"),
                ("welcome_source_message_id", "INTEGER"),
                ("welcome_media_type", "TEXT"),
                ("welcome_media_file_id", "TEXT"),
                ("welcome_caption", "TEXT"),
            ):
                if column not in existing_settings_columns:
                    await db.execute(f"ALTER TABLE group_settings ADD COLUMN {column} {sql_type}")
            await db.commit()

    async def record_chat(self, chat_id: int, chat_type: str, title: str | None) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO chats(chat_id, chat_type, title) VALUES (?, ?, ?)
                ON CONFLICT(chat_id) DO UPDATE SET chat_type=excluded.chat_type,
                title=excluded.title, updated_at=CURRENT_TIMESTAMP""",
                (chat_id, chat_type, title),
            )
            await db.commit()

    async def set_group_setting(self, chat_id: int, field: str, value: str) -> None:
        if field not in {"rules_text", "welcome_text"}:
            raise ValueError("Unsupported group setting")
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                f"""INSERT INTO group_settings(chat_id, {field}) VALUES (?, ?)
                ON CONFLICT(chat_id) DO UPDATE SET {field}=excluded.{field},
                updated_at=CURRENT_TIMESTAMP""",
                (chat_id, value),
            )
            if field == "welcome_text":
                await db.execute(
                    """UPDATE group_settings SET welcome_source_chat_id=NULL,
                    welcome_source_message_id=NULL, welcome_media_type=NULL,
                    welcome_media_file_id=NULL, welcome_caption=NULL WHERE chat_id=?""",
                    (chat_id,),
                )
            await db.commit()

    async def get_group_setting(self, chat_id: int, field: str) -> str | None:
        if field not in {"rules_text", "welcome_text"}:
            raise ValueError("Unsupported group setting")
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute(
                f"SELECT {field} FROM group_settings WHERE chat_id=?", (chat_id,)
            )
            row = await cursor.fetchone()
            return row[0] if row else None

    async def set_welcome_content(
        self,
        chat_id: int,
        text: str | None,
        source_chat_id: int | None = None,
        source_message_id: int | None = None,
        media_type: str | None = None,
        media_file_id: str | None = None,
        caption: str | None = None,
    ) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO group_settings(
                chat_id, welcome_text, welcome_source_chat_id, welcome_source_message_id,
                welcome_media_type, welcome_media_file_id, welcome_caption
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(chat_id) DO UPDATE SET welcome_text=excluded.welcome_text,
                welcome_source_chat_id=excluded.welcome_source_chat_id,
                welcome_source_message_id=excluded.welcome_source_message_id,
                welcome_media_type=excluded.welcome_media_type,
                welcome_media_file_id=excluded.welcome_media_file_id,
                welcome_caption=excluded.welcome_caption,
                updated_at=CURRENT_TIMESTAMP""",
                (
                    chat_id,
                    text,
                    source_chat_id,
                    source_message_id,
                    media_type,
                    media_file_id,
                    caption,
                ),
            )
            await db.commit()

    async def get_welcome_content(self, chat_id: int) -> dict[str, Any] | None:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                """SELECT welcome_text, welcome_source_chat_id, welcome_source_message_id,
                welcome_media_type, welcome_media_file_id, welcome_caption
                FROM group_settings WHERE chat_id=?""",
                (chat_id,),
            )
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def set_filter(
        self,
        chat_id: int,
        trigger: str,
        response: str,
        source_chat_id: int | None = None,
        source_message_id: int | None = None,
    ) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO group_filters(
                chat_id, trigger, response, source_chat_id, source_message_id
                ) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(chat_id, trigger) DO UPDATE SET response=excluded.response,
                source_chat_id=excluded.source_chat_id,
                source_message_id=excluded.source_message_id""",
                (chat_id, trigger.casefold(), response, source_chat_id, source_message_id),
            )
            await db.commit()
        self._filter_cache.pop(chat_id, None)
        self._filter_match_cache.pop(chat_id, None)

    async def remove_filter(self, chat_id: int, trigger: str) -> bool:
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute(
                "DELETE FROM group_filters WHERE chat_id=? AND trigger=?",
                (chat_id, trigger.casefold()),
            )
            await db.commit()
        self._filter_cache.pop(chat_id, None)
        self._filter_match_cache.pop(chat_id, None)
        return cursor.rowcount > 0

    async def clear_filters(self, chat_id: int) -> int:
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute("DELETE FROM group_filters WHERE chat_id=?", (chat_id,))
            await db.commit()
        self._filter_cache.pop(chat_id, None)
        self._filter_match_cache.pop(chat_id, None)
        return cursor.rowcount

    async def list_filters(self, chat_id: int) -> list[tuple[str, str]]:
        cached = self._filter_cache.get(chat_id)
        if cached is not None:
            return cached
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute(
                "SELECT trigger, response FROM group_filters WHERE chat_id=? ORDER BY trigger",
                (chat_id,),
            )
            rows = await cursor.fetchall()
            self._filter_cache[chat_id] = rows
            return rows

    async def match_filter(
        self, chat_id: int, text: str
    ) -> tuple[str, str, int | None, int | None] | None:
        filters = self._filter_match_cache.get(chat_id)
        if filters is None:
            async with aiosqlite.connect(self.path) as db:
                cursor = await db.execute(
                    """SELECT trigger, response, source_chat_id, source_message_id
                    FROM group_filters WHERE chat_id=? ORDER BY length(trigger) DESC""",
                    (chat_id,),
                )
                filters = await cursor.fetchall()
            self._filter_match_cache[chat_id] = filters
        normalized = text.casefold()
        for trigger, response, source_chat_id, source_message_id in filters:
            if trigger in normalized:
                return trigger, response, source_chat_id, source_message_id
        return None

    async def record_user(
        self, user_id: int, username: str | None, display_name: str, is_bot: bool = False
    ) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO users(user_id, username, display_name, is_bot) VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,
                display_name=excluded.display_name, is_bot=excluded.is_bot,
                last_seen=CURRENT_TIMESTAMP""",
                (user_id, username, display_name, int(is_bot)),
            )
            await db.commit()

    async def record_activity(self, chat_id: int, user_id: int, points: int) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT OR IGNORE INTO chat_members(chat_id, user_id) VALUES (?, ?)",
                (chat_id, user_id),
            )
            await db.execute(
                "UPDATE users SET points=points+?, messages=messages+1, last_seen=CURRENT_TIMESTAMP WHERE user_id=?",
                (points, user_id),
            )
            await db.execute(
                """INSERT INTO chat_activity(chat_id, user_id, points, messages) VALUES (?, ?, ?, 1)
                ON CONFLICT(chat_id, user_id) DO UPDATE SET points=points+excluded.points,
                messages=messages+1, last_seen=CURRENT_TIMESTAMP""",
                (chat_id, user_id, points),
            )
            await db.commit()

    async def record_message_activity(
        self,
        chat_id: int,
        chat_type: str,
        chat_title: str | None,
        user_id: int,
        username: str | None,
        display_name: str,
        points: int,
        is_bot: bool = False,
    ) -> None:
        """Persist chat, user, membership, and both global/chat points atomically."""
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO chats(chat_id, chat_type, title) VALUES (?, ?, ?)
                ON CONFLICT(chat_id) DO UPDATE SET chat_type=excluded.chat_type,
                title=excluded.title, updated_at=CURRENT_TIMESTAMP""",
                (chat_id, chat_type, chat_title),
            )
            await db.execute(
                """INSERT INTO users(user_id, username, display_name, is_bot) VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,
                display_name=excluded.display_name, is_bot=excluded.is_bot,
                last_seen=CURRENT_TIMESTAMP""",
                (user_id, username, display_name, int(is_bot)),
            )
            await db.execute(
                "INSERT OR IGNORE INTO chat_members(chat_id, user_id) VALUES (?, ?)",
                (chat_id, user_id),
            )
            await db.execute(
                """UPDATE users SET points=points+?, messages=messages+1,
                last_seen=CURRENT_TIMESTAMP WHERE user_id=?""",
                (points, user_id),
            )
            await db.execute(
                """INSERT INTO chat_activity(chat_id, user_id, points, messages) VALUES (?, ?, ?, 1)
                ON CONFLICT(chat_id, user_id) DO UPDATE SET points=points+excluded.points,
                messages=messages+1, last_seen=CURRENT_TIMESTAMP""",
                (chat_id, user_id, points),
            )
            await db.commit()

    async def get_leaderboard(
        self, limit: int = 10, chat_id: int | None = None
    ) -> list[UserRecord]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            if chat_id is None:
                cursor = await db.execute(
                    """SELECT user_id, username, display_name, points, messages FROM users
                    WHERE is_bot=0 ORDER BY points DESC, messages DESC LIMIT ?""",
                    (limit,),
                )
            else:
                cursor = await db.execute(
                    """SELECT u.user_id, u.username, u.display_name,
                    a.points, a.messages FROM chat_activity a
                    JOIN users u ON u.user_id=a.user_id
                    WHERE a.chat_id=? AND u.is_bot=0
                    ORDER BY a.points DESC, a.messages DESC LIMIT ?""",
                    (chat_id, limit),
                )
            return [UserRecord(**dict(row)) for row in await cursor.fetchall()]

    async def get_group_leaderboard(self, limit: int = 10) -> list[dict[str, Any]]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                """SELECT c.chat_id, c.title,
                COALESCE(SUM(a.points), 0) AS points,
                COALESCE(SUM(a.messages), 0) AS messages
                FROM chats c JOIN chat_activity a ON a.chat_id=c.chat_id
                WHERE c.chat_type IN ('group', 'supergroup')
                GROUP BY c.chat_id, c.title
                HAVING SUM(a.messages) > 0
                ORDER BY messages DESC, points DESC
                LIMIT ?""",
                (limit,),
            )
            return [dict(row) for row in await cursor.fetchall()]

    async def get_user(self, user_id: int) -> UserRecord | None:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT user_id, username, display_name, points, messages FROM users WHERE user_id=?",
                (user_id,),
            )
            row = await cursor.fetchone()
            return UserRecord(**dict(row)) if row else None

    async def get_user_rank(self, user_id: int, chat_id: int | None = None) -> int | None:
        async with aiosqlite.connect(self.path) as db:
            if chat_id is None:
                cursor = await db.execute(
                    "SELECT points, messages FROM users WHERE user_id=? AND is_bot=0", (user_id,)
                )
            else:
                cursor = await db.execute(
                    """SELECT points, messages FROM chat_activity
                    WHERE chat_id=? AND user_id IN (SELECT user_id FROM users WHERE is_bot=0)
                    AND user_id=?""",
                    (chat_id, user_id),
                )
            current = await cursor.fetchone()
            if not current:
                return None
            if chat_id is None:
                cursor = await db.execute(
                    """SELECT COUNT(*) FROM users WHERE is_bot=0 AND
                    (points > ? OR (points = ? AND messages > ?))""",
                    (current[0], current[0], current[1]),
                )
            else:
                cursor = await db.execute(
                    """SELECT COUNT(*) FROM chat_activity a JOIN users u ON u.user_id=a.user_id
                    WHERE a.chat_id=? AND u.is_bot=0 AND
                    (a.points > ? OR (a.points = ? AND a.messages > ?))""",
                    (chat_id, current[0], current[0], current[1]),
                )
            return (await cursor.fetchone())[0] + 1

    async def get_chats(self) -> list[int]:
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute("SELECT chat_id FROM chats")
            return [row[0] for row in await cursor.fetchall()]

    async def add_admin(self, user_id: int, username: str | None, display_name: str) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT OR REPLACE INTO admins(user_id, username, display_name) VALUES (?, ?, ?)",
                (user_id, username, display_name),
            )
            await db.commit()

    async def remove_admin(self, user_id: int) -> bool:
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute("DELETE FROM admins WHERE user_id=?", (user_id,))
            await db.commit()
            return cursor.rowcount > 0

    async def is_admin(self, user_id: int, owner_id: int) -> bool:
        if user_id == owner_id:
            return True
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute("SELECT 1 FROM admins WHERE user_id=?", (user_id,))
            return await cursor.fetchone() is not None

    async def list_admins(self) -> list[dict[str, Any]]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT user_id, username, display_name, added_at FROM admins ORDER BY added_at"
            )
            return [dict(row) for row in await cursor.fetchall()]

    async def add_warning(self, chat_id: int, user_id: int) -> int:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO warnings(chat_id, user_id, count) VALUES (?, ?, 1)
                ON CONFLICT(chat_id, user_id) DO UPDATE SET count=count+1,
                updated_at=CURRENT_TIMESTAMP""",
                (chat_id, user_id),
            )
            cursor = await db.execute(
                "SELECT count FROM warnings WHERE chat_id=? AND user_id=?", (chat_id, user_id)
            )
            count = (await cursor.fetchone())[0]
            await db.commit()
            return count

    async def remove_warning(self, chat_id: int, user_id: int) -> int:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE warnings SET count=MAX(0, count-1), updated_at=CURRENT_TIMESTAMP WHERE chat_id=? AND user_id=?",
                (chat_id, user_id),
            )
            cursor = await db.execute(
                "SELECT COALESCE(count, 0) FROM warnings WHERE chat_id=? AND user_id=?",
                (chat_id, user_id),
            )
            row = await cursor.fetchone()
            await db.commit()
            return row[0] if row else 0

    async def global_stats(self) -> dict[str, int]:
        async with aiosqlite.connect(self.path) as db:
            result: dict[str, int] = {}
            for key, sql in {
                "users": "SELECT COUNT(*) FROM users WHERE is_bot=0",
                "chats": "SELECT COUNT(*) FROM chats",
                "messages": "SELECT COALESCE(SUM(messages), 0) FROM users WHERE is_bot=0",
                "points": "SELECT COALESCE(SUM(points), 0) FROM users WHERE is_bot=0",
            }.items():
                cursor = await db.execute(sql)
                result[key] = (await cursor.fetchone())[0]
            return result

    async def get_known_users(self) -> list[UserRecord]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT user_id, username, display_name, points, messages FROM users WHERE is_bot=0"
            )
            return [UserRecord(**dict(row)) for row in await cursor.fetchall()]

    async def find_user_by_username(self, username: str) -> UserRecord | None:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                """SELECT user_id, username, display_name, points, messages FROM users
                WHERE lower(username)=lower(?) AND is_bot=0 LIMIT 1""",
                (username.lstrip("@"),),
            )
            row = await cursor.fetchone()
            return UserRecord(**dict(row)) if row else None
