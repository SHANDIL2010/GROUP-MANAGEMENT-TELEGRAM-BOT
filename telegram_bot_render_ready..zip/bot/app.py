from __future__ import annotations

import logging

from telegram import BotCommand
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    MessageHandler,
    filters,
)

from .config import get_settings
from .handlers_commands import (
    add_admin,
    admins,
    ban,
    bot_info,
    button_router,
    global_stats,
    help_command,
    leaderboard,
    list_group_filters,
    mystats,
    promote_group_admin,
    rank,
    remove_admin,
    remove_group_filter,
    rules,
    set_group_filter,
    set_rules,
    set_welcome,
    show_welcome,
    start,
    unban,
    unwarn,
    user_id_info,
    warn,
)
from .handlers_events import (
    broadcast,
    farewell_left_member,
    track_and_moderate,
    welcome_new_members,
)
from .repository import Repository
from .services import FloodGuard

logger = logging.getLogger(__name__)


async def post_init(application: Application) -> None:
    await application.bot_data["repo"].initialize()
    await application.bot.set_my_commands(
        [
            BotCommand("start", "Open the bot menu"),
            BotCommand("help", "Show help"),
            BotCommand("leaderboard", "View the top members"),
            BotCommand("mystats", "View your activity stats"),
            BotCommand("rank", "View your rank"),
            BotCommand("rules", "View community rules"),
            BotCommand("welcome", "View the group welcome message"),
            BotCommand("id", "View your Telegram IDs"),
            BotCommand("admins", "View configured admins"),
            BotCommand("admin", "Promote a joined group member"),
            BotCommand("setrules", "Set group rules (admins)"),
            BotCommand("setwelcome", "Set group welcome (admins)"),
            BotCommand("filters", "View group auto-replies"),
            BotCommand("rfilter", "Remove group auto-replies (admins)"),
        ]
    )
    logger.info("Bot initialized with database %s", application.bot_data["settings"].database_path)


async def error_handler(update: object, context) -> None:
    logger.error("Unhandled Telegram update error", exc_info=context.error)


def build_application() -> Application:
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    application = (
        ApplicationBuilder()
        .token(settings.bot_token)
        .connect_timeout(30)
        .read_timeout(30)
        .write_timeout(30)
        .pool_timeout(30)
        .get_updates_connect_timeout(30)
        .get_updates_read_timeout(30)
        .get_updates_write_timeout(30)
        .get_updates_pool_timeout(30)
        .concurrent_updates(True)
        .post_init(post_init)
        .build()
    )
    application.bot_data["settings"] = settings
    application.bot_data["repo"] = Repository(settings.database_path)
    application.bot_data["flood_guard"] = FloodGuard(
        settings.flood_window_seconds, settings.flood_max_messages
    )

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler(["leaderboard", "top"], leaderboard))
    application.add_handler(CommandHandler("mystats", mystats))
    application.add_handler(CommandHandler("rank", rank))
    application.add_handler(CommandHandler("rules", rules))
    application.add_handler(CommandHandler("welcome", show_welcome))
    application.add_handler(CommandHandler("setrules", set_rules))
    application.add_handler(CommandHandler("setwelcome", set_welcome))
    application.add_handler(CommandHandler("filter", set_group_filter))
    application.add_handler(CommandHandler("filters", list_group_filters))
    application.add_handler(CommandHandler("rfilter", remove_group_filter))
    application.add_handler(CommandHandler("id", user_id_info))
    application.add_handler(CommandHandler("admins", admins))
    application.add_handler(CommandHandler("admin", promote_group_admin))
    application.add_handler(CommandHandler("addadmin", add_admin))
    application.add_handler(CommandHandler("removeadmin", remove_admin))
    application.add_handler(CommandHandler("warn", warn))
    application.add_handler(CommandHandler("unwarn", unwarn))
    application.add_handler(CommandHandler("ban", ban))
    application.add_handler(CommandHandler("unban", unban))
    application.add_handler(CommandHandler("stats", global_stats))
    application.add_handler(CommandHandler("botinfo", bot_info))
    application.add_handler(CommandHandler("broadcast", broadcast))
    application.add_handler(
        CallbackQueryHandler(button_router, pattern="^(leaderboard|mystats|features|help|home)$")
    )
    application.add_handler(
        MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome_new_members)
    )
    application.add_handler(
        MessageHandler(filters.StatusUpdate.LEFT_CHAT_MEMBER, farewell_left_member)
    )
    application.add_handler(
        MessageHandler(
            (filters.ALL & ~filters.COMMAND) & ~filters.StatusUpdate.ALL, track_and_moderate
        )
    )
    application.add_error_handler(error_handler)
    return application
