from __future__ import annotations

import logging
from html import escape

from telegram import Update
from telegram.error import TelegramError
from telegram.ext import ContextTypes

from .services import FloodGuard, bold, contains_bad_word, mention, require_bot_admin

logger = logging.getLogger(__name__)


async def welcome_new_members(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if not message or not message.new_chat_members:
        return
    saved = await context.application.bot_data["repo"].get_welcome_content(message.chat_id)
    welcome = (saved and saved.get("welcome_text")) or (
        "Welcome @username! Please read the group rules and enjoy your stay."
    )
    for user in message.new_chat_members:
        if user.is_bot:
            continue
        username = f"@{user.username}" if user.username else user.full_name
        personalized = (
            escape(welcome).replace("@username", escape(username)).replace("@userid", str(user.id))
        )
        media_type = saved.get("welcome_media_type") if saved else None
        media_file_id = saved.get("welcome_media_file_id") if saved else None
        try:
            if media_type == "photo" and media_file_id:
                await message.reply_photo(
                    photo=media_file_id, caption=bold(personalized), parse_mode="HTML"
                )
            elif media_type == "animation" and media_file_id:
                await message.reply_animation(
                    animation=media_file_id, caption=bold(personalized), parse_mode="HTML"
                )
            elif media_type == "video" and media_file_id:
                await message.reply_video(
                    video=media_file_id, caption=bold(personalized), parse_mode="HTML"
                )
            else:
                await message.reply_text(bold(personalized), parse_mode="HTML")
        except TelegramError:
            logger.warning("Could not send saved welcome media", exc_info=True)
            await message.reply_text(bold(personalized), parse_mode="HTML")
        await context.application.bot_data["repo"].record_user(
            user.id, user.username, user.full_name, is_bot=False
        )


async def farewell_left_member(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    member = message.left_chat_member if message else None
    if not message or not member or member.is_bot:
        return
    greeting = mention(member.id, member.username, member.full_name)
    await message.reply_text(
        bold(
            f"👋 Goodbye, {greeting}! Thanks for being part of our community. "
            "We wish you all the best, and you are always welcome back."
        ),
        parse_mode="HTML",
    )


async def track_and_moderate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    user = update.effective_user
    chat = update.effective_chat
    if not message or not user or not chat or user.is_bot:
        return
    repo = context.application.bot_data["repo"]
    settings = context.application.bot_data["settings"]
    context.application.create_task(
        repo.record_message_activity(
            chat.id,
            chat.type,
            chat.title or user.full_name,
            user.id,
            user.username,
            user.full_name,
            settings.points_per_message,
            is_bot=user.is_bot,
        ),
        update=update,
    )

    text = message.text or message.caption
    guard: FloodGuard = context.application.bot_data["flood_guard"]
    if chat.type != "private" and guard.hit(chat.id, user.id):
        try:
            await message.delete()
        except TelegramError:
            logger.debug("Could not delete flood message", exc_info=True)
        return
    if chat.type != "private" and contains_bad_word(text, settings.bad_words):
        try:
            await message.delete()
        except TelegramError:
            logger.debug("Could not delete moderated message", exc_info=True)
        count = await repo.add_warning(chat.id, user.id)
        if count >= settings.warning_threshold:
            try:
                await context.bot.ban_chat_member(chat.id, user.id)
                await chat.send_message(
                    bold(f"{user.full_name} was banned after reaching {count} warnings."),
                    parse_mode="HTML",
                )
            except TelegramError:
                await chat.send_message(
                    bold(
                        f"{user.full_name} reached {count} warnings. Please review their moderation status."
                    ),
                    parse_mode="HTML",
                )
        else:
            await chat.send_message(
                bold(
                    f"{user.full_name}, that language is not allowed. Warning {count}/{settings.warning_threshold}."
                ),
                parse_mode="HTML",
            )
    if chat.type != "private" and text:
        matched = await repo.match_filter(chat.id, text)
        if matched:
            _, response, source_chat_id, source_message_id = matched
            if source_chat_id is not None and source_message_id is not None:
                try:
                    await context.bot.copy_message(
                        chat_id=chat.id,
                        from_chat_id=source_chat_id,
                        message_id=source_message_id,
                    )
                except TelegramError:
                    await chat.send_message(bold(escape(response)), parse_mode="HTML")
            else:
                await chat.send_message(bold(escape(response)), parse_mode="HTML")


async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # This is a global bot-admin action: group membership/admin status alone is not enough.
    if not await require_bot_admin(update, context):
        return
    source = update.effective_message.reply_to_message if update.effective_message else None
    if not source:
        await update.effective_message.reply_text(
            bold("Reply to the message you want to broadcast."), parse_mode="HTML"
        )
        return
    repo = context.application.bot_data["repo"]
    delivered = failed = 0
    for chat_id in await repo.get_chats():
        try:
            await context.bot.copy_message(
                chat_id=chat_id, from_chat_id=source.chat_id, message_id=source.message_id
            )
            delivered += 1
        except TelegramError:
            failed += 1
            logger.warning("Broadcast failed for chat %s", chat_id, exc_info=True)
    await update.effective_message.reply_text(
        bold(f"Broadcast complete: {delivered} delivered, {failed} failed."),
        parse_mode="HTML",
    )
