from .app import build_application


def main() -> None:
    build_application().run_polling(allowed_updates=None, bootstrap_retries=-1)


if __name__ == "__main__":
    main()
