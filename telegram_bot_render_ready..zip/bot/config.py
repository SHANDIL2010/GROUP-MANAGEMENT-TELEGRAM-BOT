"""Application configuration loaded exclusively from environment variables."""

from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str = Field(min_length=1, validation_alias="BOT_TOKEN")
    owner_id: int = Field(validation_alias="OWNER_ID")
    bad_words: list[str] = Field(default_factory=list, validation_alias="BAD_WORDS")
    flood_window_seconds: int = Field(default=8, ge=1, validation_alias="FLOOD_WINDOW_SECONDS")
    flood_max_messages: int = Field(default=6, ge=2, validation_alias="FLOOD_MAX_MESSAGES")
    warning_threshold: int = Field(default=3, ge=1, validation_alias="WARNING_THRESHOLD")
    points_per_message: int = Field(default=1, ge=1, validation_alias="POINTS_PER_MESSAGE")
    database_path: str = Field(default="bot.sqlite3", validation_alias="DATABASE_PATH")
    start_image_path: str = Field(
        default="assets/start_welcome.jpg", validation_alias="START_IMAGE_PATH"
    )
    log_level: str = Field(default="INFO", validation_alias="LOG_LEVEL")

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @field_validator("bad_words", mode="before")
    @classmethod
    def parse_bad_words(cls, value: object) -> list[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [word.strip().casefold() for word in value.split(",") if word.strip()]
        return list(value)


@lru_cache
def get_settings() -> Settings:
    return Settings()
