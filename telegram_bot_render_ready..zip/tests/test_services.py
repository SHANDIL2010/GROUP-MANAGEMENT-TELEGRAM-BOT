from bot.services import FloodGuard, contains_bad_word


def test_bad_word_matching_is_case_insensitive_and_word_bounded():
    assert contains_bad_word("This contains BADWORD.", ["badword"])
    assert not contains_bad_word("badwording is not an exact word", ["badword"])


def test_flood_guard_trips_after_limit():
    guard = FloodGuard(window_seconds=10, max_messages=2)
    assert not guard.hit(1, 2)
    assert not guard.hit(1, 2)
    assert guard.hit(1, 2)
