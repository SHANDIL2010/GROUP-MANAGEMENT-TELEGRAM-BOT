import pytest

from bot.repository import Repository


@pytest.mark.asyncio
async def test_repository_tracks_activity_and_leaderboard(tmp_path):
    repo = Repository(str(tmp_path / "test.sqlite3"))
    await repo.initialize()
    await repo.record_chat(10, "group", "Test")
    await repo.record_user(20, "alice", "Alice")
    await repo.record_activity(10, 20, 1)
    await repo.record_activity(10, 20, 1)
    rows = await repo.get_leaderboard()
    assert rows[0].user_id == 20
    assert rows[0].points == 2
    assert rows[0].messages == 2
    assert await repo.get_chats() == [10]


@pytest.mark.asyncio
async def test_repository_batches_message_activity(tmp_path):
    repo = Repository(str(tmp_path / "batched.sqlite3"))
    await repo.initialize()
    await repo.record_message_activity(10, "group", "Test", 20, "alice", "Alice", 1)
    row = await repo.get_user(20)
    assert row is not None
    assert row.points == 1
    assert await repo.find_user_by_username("@ALICE") is not None


@pytest.mark.asyncio
async def test_leaderboards_are_scoped_and_exclude_bots(tmp_path):
    repo = Repository(str(tmp_path / "scoped.sqlite3"))
    await repo.initialize()
    await repo.record_message_activity(100, "group", "Group", 1, "alice", "Alice", 1)
    await repo.record_message_activity(100, "group", "Group", 2, "bob", "Bob", 3)
    await repo.record_message_activity(200, "group", "Other", 1, "alice", "Alice", 5)
    await repo.record_message_activity(
        100, "group", "Group", 3, "helper_bot", "Helper", 99, is_bot=True
    )

    group_rows = await repo.get_leaderboard(chat_id=100)
    global_rows = await repo.get_leaderboard()
    assert [row.user_id for row in group_rows] == [2, 1]
    assert all(row.user_id != 3 for row in global_rows)


@pytest.mark.asyncio
async def test_group_settings_are_persistent(tmp_path):
    repo = Repository(str(tmp_path / "settings.sqlite3"))
    await repo.initialize()
    await repo.set_group_setting(100, "rules_text", "Be kind.")
    await repo.set_group_setting(100, "welcome_text", "Welcome to our group!")
    assert await repo.get_group_setting(100, "rules_text") == "Be kind."
    assert await repo.get_group_setting(100, "welcome_text") == "Welcome to our group!"


@pytest.mark.asyncio
async def test_group_filters_match_words_and_emoji(tmp_path):
    repo = Repository(str(tmp_path / "filters.sqlite3"))
    await repo.initialize()
    await repo.set_filter(100, "hello", "Hello there!")
    await repo.set_filter(100, "💜", "Purple hearts!")
    assert await repo.match_filter(100, "HELLO everyone") == ("hello", "Hello there!", None, None)
    assert await repo.match_filter(100, "Great 💜") == ("💜", "Purple hearts!", None, None)
    assert await repo.match_filter(200, "hello") is None


@pytest.mark.asyncio
async def test_group_leaderboard_ranks_groups_by_activity(tmp_path):
    repo = Repository(str(tmp_path / "groups.sqlite3"))
    await repo.initialize()
    await repo.record_message_activity(100, "group", "Busy Group", 1, "alice", "Alice", 1)
    await repo.record_message_activity(100, "group", "Busy Group", 1, "alice", "Alice", 1)
    await repo.record_message_activity(200, "supergroup", "Quiet Group", 2, "bob", "Bob", 1)
    rows = await repo.get_group_leaderboard()
    assert [row["title"] for row in rows] == ["Busy Group", "Quiet Group"]


@pytest.mark.asyncio
async def test_group_filters_can_be_removed(tmp_path):
    repo = Repository(str(tmp_path / "remove-filters.sqlite3"))
    await repo.initialize()
    await repo.set_filter(100, "hello", "Hi")
    await repo.set_filter(100, "bye", "Goodbye")
    assert await repo.remove_filter(100, "HELLO") is True
    assert await repo.match_filter(100, "hello") is None
    assert await repo.clear_filters(100) == 1
    assert await repo.list_filters(100) == []
