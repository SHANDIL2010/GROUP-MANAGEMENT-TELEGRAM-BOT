# Telegram Group Tag Bot

A Node.js bot using [`node-telegram-bot-api`](https://github.com/yagop/node-telegram-bot-api) that provides admin-only tagging commands in Telegram groups and supergroups, plus an owner-only broadcast command.

## Important Telegram API limitation

Telegram's Bot API does **not** provide an endpoint for downloading every historical member of a group. Therefore `/tagall` tags:

- Members the bot has observed sending messages or joining while it is running; and
- All current group admins (fetched live), including the group owner.

To observe ordinary members, turn off **Group Privacy** for the bot in `@BotFather` (`/setprivacy` → `Disable`) and keep the bot in the group. The member cache is in memory and resets when the process restarts. This is a Telegram API limitation, not a code limitation.

## Setup

1. Create a new bot with `@BotFather` and copy its token.
2. Add the bot to each target group.
3. Promote the bot to an administrator with permission to read messages and send messages. It does not need to add members or delete messages.
4. Disable Group Privacy in `@BotFather` if you want the bot to observe normal member messages.
5. Install and configure:

```bash
npm install
cp .env.example .env
# Edit .env and set BOT_TOKEN and BOT_OWNER_ID
npm start
```

The bot intentionally ignores private messages and non-group chats. It learns a group for broadcasting when it receives a message from that group, and stores known group IDs in `data/groups.json` so they survive restarts.

## Configuration

| Variable | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | Yes | Token from `@BotFather` |
| `BOT_OWNER_ID` | Yes for `/broadcast` | Numeric Telegram user ID of the only user allowed to broadcast |
| `RATE_LIMIT_MS` | No | Per-group cooldown for tagging/help commands; default `10000` |
| `BROADCAST_DELAY_MS` | No | Delay between broadcast messages to reduce Telegram rate-limit risk; default `100` |
| `MAX_MESSAGE_LENGTH` | No | Outgoing tag chunk size; default `4000`, maximum `4096` |

## Commands

- `/tagall` or `/all` — tags all observed members plus current admins.
- `/tagall Hello everyone, meeting starts in 5 minutes!` — adds a custom message to the final tag message.
- `/tagadmins` — tags current group admins and owner.
- `/help` — displays the short help message.
- `/broadcast Your announcement here` — **bot owner only**; sends the plain-text message to every known group.

### Broadcast details

- `/broadcast` must be sent inside a group because the bot ignores private messages by design.
- Only the exact numeric `BOT_OWNER_ID` can use it; group admins cannot use it unless they are also the configured bot owner.
- The bot sends to groups it has previously observed. It cannot discover groups where it has never received an update.
- Messages are limited to Telegram's 4096-character limit.
- Failed or inaccessible groups are reported in the completion message, and groups returning common “removed/not found” errors are removed from `data/groups.json`.
- A small delay is applied between sends to reduce rate-limit risk.

Users without usernames are mentioned with Telegram `text_mention`-style HTML links (`tg://user?id=...`), while users with usernames use `@username`.

## Security

Never commit `.env`, `data/groups.json`, or share the bot token. The token previously shared during setup should be revoked and regenerated with `@BotFather` if it has been exposed anywhere outside the private `.env` file.

## Hosting choices

| Approach | Tradeoffs | Cost | Setup complexity |
| --- | --- | --- | --- |
| Run this Node process on an always-on host | Immediate responses; requires the process to stay online | Depends on host | Low |
| Use a managed webhook/Node host | Better uptime and deployment workflow; requires webhook setup | Depends on provider | Medium |

For testing, run `npm start` locally. For real use, use a host with a persistent Node.js process, store `BOT_TOKEN` as a secret environment variable, and preserve the `data/` directory.
