'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');

const token = process.env.BOT_TOKEN;
if (!token) {
  console.error('Missing BOT_TOKEN. Copy .env.example to .env and set BOT_TOKEN.');
  process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });
const botOwnerId = process.env.BOT_OWNER_ID ? Number(process.env.BOT_OWNER_ID) : null;
const rateLimitMs = Math.max(0, Number(process.env.RATE_LIMIT_MS || 10000));
const broadcastDelayMs = Math.max(0, Number(process.env.BROADCAST_DELAY_MS || 100));
const maxMessageLength = Math.min(4096, Math.max(1000, Number(process.env.MAX_MESSAGE_LENGTH || 4000)));
const dataDirectory = path.join(__dirname, '..', 'data');
const groupsFile = path.join(dataDirectory, 'groups.json');

// Telegram does not expose a get-all-members endpoint. This cache contains users
// the bot has seen in messages/events, and is persisted only for this process.
const membersByChat = new Map(); // chatId -> Map(userId, user)
const lastUseByChat = new Map();
const knownGroups = loadKnownGroups();

function isGroupChat(chat) {
  return chat && (chat.type === 'group' || chat.type === 'supergroup');
}

function loadKnownGroups() {
  try {
    const saved = JSON.parse(fs.readFileSync(groupsFile, 'utf8'));
    if (!Array.isArray(saved)) return new Map();
    return new Map(saved.map((group) => [String(group.id), group]));
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Could not load known groups:', error.message);
    return new Map();
  }
}

function saveKnownGroups() {
  try {
    fs.mkdirSync(dataDirectory, { recursive: true });
    fs.writeFileSync(groupsFile, `${JSON.stringify([...knownGroups.values()], null, 2)}\n`);
  } catch (error) {
    console.error('Could not save known groups:', error.message);
  }
}

function rememberGroup(chat) {
  const key = String(chat.id);
  const previous = knownGroups.get(key);
  const next = {
    id: chat.id,
    title: chat.title || previous?.title || key,
    type: chat.type,
    firstSeenAt: previous?.firstSeenAt || new Date().toISOString(),
    lastSeenAt: new Date().toISOString()
  };
  knownGroups.set(key, next);
  if (!previous || previous.title !== next.title || previous.type !== next.type) saveKnownGroups();
}

function rememberUser(chatId, user) {
  if (!user || user.is_bot || user.id == null) return;
  if (!membersByChat.has(chatId)) membersByChat.set(chatId, new Map());
  membersByChat.get(chatId).set(user.id, {
    id: user.id,
    username: user.username,
    first_name: user.first_name || 'Telegram user',
    last_name: user.last_name || ''
  });
}

function displayName(user) {
  return [user.first_name, user.last_name].filter(Boolean).join(' ').trim() || 'Telegram user';
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function mention(user) {
  if (user.username) return `@${user.username}`;
  return `<a href="tg://user?id=${user.id}">${escapeHtml(displayName(user))}</a>`;
}

function parseCommand(text = '') {
  const match = text.trim().match(/^\/(tagall|all|tagadmins|broadcast|help)(?:@[^\s]+)?(?:\s+([\s\S]*))?$/i);
  return match ? { command: match[1].toLowerCase(), argument: (match[2] || '').trim() } : null;
}

function chunkMentions(mentions, suffix = '') {
  const chunks = [];
  let current = '';
  for (const item of mentions) {
    const candidate = current ? `${current} ${item}` : item;
    if ((candidate + suffix).length > maxMessageLength && current) {
      chunks.push(current);
      current = item;
    } else {
      current = candidate;
    }
  }
  if (current) chunks.push(current);
  if (!chunks.length && suffix) chunks.push(suffix.trim());
  return chunks;
}

async function isAuthorized(chatId, userId) {
  if (botOwnerId && userId === botOwnerId) return true;
  try {
    const member = await bot.getChatMember(chatId, userId);
    return member.status === 'administrator' || member.status === 'creator';
  } catch (error) {
    console.error(`Could not check permissions for ${userId} in ${chatId}:`, error.message);
    return false;
  }
}

async function getAdmins(chatId) {
  const admins = await bot.getChatAdministrators(chatId);
  return admins
    .map((entry) => entry.user)
    .filter((user) => user && !user.is_bot)
    .map((user) => ({
      id: user.id,
      username: user.username,
      first_name: user.first_name || 'Telegram user',
      last_name: user.last_name || ''
    }));
}

async function sendHelp(chatId) {
  await bot.sendMessage(chatId,
    '<b>Group tag bot</b>\n' +
    '/tagall or /all [message] — tag members the bot has observed\n' +
    '/tagadmins — tag group admins and owner\n' +
    '/help — show this help\n\n' +
    '<b>Owner only:</b> /broadcast [message] — send a message to all known groups\n\n' +
    'Tag commands are available only to group admins and the group owner.',
    { parse_mode: 'HTML' }
  );
}

async function handleTagAll(chatId, customMessage) {
  const cached = [...(membersByChat.get(chatId)?.values() || [])];
  const admins = await getAdmins(chatId);
  const byId = new Map(cached.map((user) => [user.id, user]));
  for (const admin of admins) byId.set(admin.id, admin);
  const users = [...byId.values()].sort((a, b) => displayName(a).localeCompare(displayName(b)));

  if (!users.length) {
    await bot.sendMessage(chatId, 'I have not observed any members yet. Disable Group Privacy for this bot in @BotFather, then let members send a message and try again.');
    return;
  }

  const suffix = customMessage ? `\n\n${escapeHtml(customMessage)}` : '';
  const chunks = chunkMentions(users.map(mention), suffix);
  for (let index = 0; index < chunks.length; index += 1) {
    const text = index === chunks.length - 1 && suffix ? `${chunks[index]}${suffix}` : chunks[index];
    await bot.sendMessage(chatId, text, { parse_mode: 'HTML', disable_web_page_preview: true });
  }
  console.log(`Tagged ${users.length} observed members in chat ${chatId}`);
}

async function handleTagAdmins(chatId) {
  const admins = await getAdmins(chatId);
  if (!admins.length) {
    await bot.sendMessage(chatId, 'I could not retrieve the group admins. Check that I have permission to read group information.');
    return;
  }
  for (const chunk of chunkMentions(admins.map(mention))) {
    await bot.sendMessage(chatId, chunk, { parse_mode: 'HTML', disable_web_page_preview: true });
  }
  console.log(`Tagged ${admins.length} admins in chat ${chatId}`);
}

function sleep(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function handleBroadcast(sourceChatId, text) {
  if (!botOwnerId) {
    await bot.sendMessage(sourceChatId, 'Broadcast is disabled because BOT_OWNER_ID is not configured.');
    return;
  }
  if (!text) {
    await bot.sendMessage(sourceChatId, 'Usage: /broadcast Your message here');
    return;
  }
  if (text.length > 4096) {
    await bot.sendMessage(sourceChatId, 'Broadcast message is too long. Telegram allows a maximum of 4096 characters per message.');
    return;
  }

  const groups = [...knownGroups.values()];
  if (!groups.length) {
    await bot.sendMessage(sourceChatId, 'No known groups yet. The bot learns a group when it receives a message there.');
    return;
  }

  let sent = 0;
  let failed = 0;
  for (const group of groups) {
    try {
      await bot.sendMessage(group.id, text, { disable_web_page_preview: true });
      sent += 1;
    } catch (error) {
      failed += 1;
      console.error(`Broadcast failed for ${group.id} (${group.title}):`, error.message);
      // Remove groups where the bot was removed or the chat no longer exists.
      if (/chat not found|bot was kicked|forbidden/i.test(error.message)) knownGroups.delete(String(group.id));
    }
    if (broadcastDelayMs) await sleep(broadcastDelayMs);
  }
  saveKnownGroups();
  await bot.sendMessage(sourceChatId, `Broadcast complete. Sent: ${sent}. Failed: ${failed}. Known groups: ${knownGroups.size}.`);
  console.log(`Owner broadcast from ${sourceChatId}: sent=${sent}, failed=${failed}`);
}

bot.on('message', async (message) => {
  const chat = message.chat;
  if (!isGroupChat(chat)) return; // Ignore private chats, channels, and other chat types.

  rememberGroup(chat);
  rememberUser(chat.id, message.from);
  for (const newMember of message.new_chat_members || []) rememberUser(chat.id, newMember);

  const parsed = parseCommand(message.text);
  if (!parsed) return;

  try {
    if (parsed.command === 'broadcast') {
      if (!botOwnerId || message.from.id !== botOwnerId) {
        await bot.sendMessage(chat.id, 'Only the bot owner can use /broadcast.');
        return;
      }
      await handleBroadcast(chat.id, parsed.argument);
      return;
    }

    if (!(await isAuthorized(chat.id, message.from.id))) {
      await bot.sendMessage(chat.id, 'Only group admins and the owner can use this bot.');
      return;
    }

    const now = Date.now();
    const lastUse = lastUseByChat.get(chat.id) || 0;
    if (now - lastUse < rateLimitMs) {
      await bot.sendMessage(chat.id, `Please wait ${Math.ceil((rateLimitMs - (now - lastUse)) / 1000)} seconds before using the bot again.`);
      return;
    }
    lastUseByChat.set(chat.id, now);

    if (parsed.command === 'help') await sendHelp(chat.id);
    else if (parsed.command === 'tagall' || parsed.command === 'all') await handleTagAll(chat.id, parsed.argument);
    else if (parsed.command === 'tagadmins') await handleTagAdmins(chat.id);
  } catch (error) {
    console.error(`Command /${parsed.command} failed in chat ${chat.id}:`, error.message);
    await bot.sendMessage(chat.id, 'I could not complete that request. Please check my group permissions and try again.').catch((sendError) => console.error('Error sending failure message:', sendError.message));
  }
});

bot.on('polling_error', (error) => console.error('Telegram polling error:', error.message));
process.on('SIGINT', () => { bot.stopPolling(); process.exit(0); });
process.on('SIGTERM', () => { bot.stopPolling(); process.exit(0); });

console.log('Telegram group tag bot is running.');
